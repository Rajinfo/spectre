package me.test.controller;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;
import me.test.service.impl.HeroServiceImpl;

@RestController
@RequestMapping("/call")
@Tag(name = "Heroes Controller", description = "RESTful API for managing heroes.")
public class HeroController {
	
	@Autowired
	HeroServiceImpl heroService;

	@GetMapping("/sync")
    public String syncCall() {
        long startTime = System.currentTimeMillis();
        String response = heroService.getResponseSync();
        long endTime = System.currentTimeMillis();
        return "Synchronous call took: " + (endTime - startTime) + " ms, Response: " + response;
    }

    @GetMapping("/async")
    public CompletableFuture<String> asyncCall() {
        long startTime = System.currentTimeMillis();
        return heroService.getResponseAsync().thenApply(response -> {
            long endTime = System.currentTimeMillis();
            return "Asynchronous call took: " + (endTime - startTime) + " ms, Response: " + response;
        });
    }

   

   

    
}
