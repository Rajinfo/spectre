package me.test.service.impl;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class HeroServiceImpl {

   

	 private final RestTemplate restTemplate = new RestTemplate();
	 private final ExecutorService executorService = Executors.newCachedThreadPool();

	   

	    /**
	     * @return
	     */
	    public String getResponseSync() {
	        String url = "http://localhost:8080/heroes";
	        return restTemplate.getForObject(url, String.class);
	    }

	    /**
	     * @return
	     */
	    public CompletableFuture<String> getResponseAsync() {
	        return CompletableFuture.supplyAsync(() -> {
	            String url = "http://localhost:8080/heroes";
	            return restTemplate.getForObject(url, String.class);
	        }, executorService);
	    }

  
}