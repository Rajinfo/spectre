package me.test.service;

import java.util.List;

import me.test.model.Hero;

public interface CrudService {
   public List<Hero> findAll();
    public Hero create(Hero hero);
}
