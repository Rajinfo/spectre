package me.test.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import me.test.model.Hero;
import me.test.service.CrudService;

@Service
public class HeroServiceImpl implements CrudService {

   

    public List<Hero> findAll() {
        // DONE! Sort Heroes by "xp" descending.
    	List<Hero> test = new ArrayList<>();
    	Hero h = new Hero();
    	h.setId(1L);
    	h.setName("test");
    	test.add(h);
        return test;
    }

  

    public Hero create(Hero heroToCreate) {
    	Hero h = new Hero();
    	h.setId(1L);
    	h.setName("test2");
        return  h;
    }

  
}