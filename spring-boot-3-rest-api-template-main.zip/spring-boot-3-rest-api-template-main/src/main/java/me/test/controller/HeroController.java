package me.test.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import me.test.model.Hero;
import me.test.service.CrudService;

@RestController
@RequestMapping("/heroes")
@Tag(name = "Heroes Controller", description = "RESTful API for managing heroes.")
public class HeroController {
	
	@Autowired
	CrudService heroService;

    @GetMapping
    @Operation(summary = "Get all heroes", description = "Get a list of all registered heroes")
    @ApiResponses(value = { 
            @ApiResponse(responseCode = "200", description = "Successful operation")
    })
    public ResponseEntity<List<Hero>> findAll() {
        return ResponseEntity.ok(heroService.findAll());
    }

   

    @PostMapping
    @Operation(summary = "Create a new hero", description = "Create a new hero and returns the created hero")
    @ApiResponses(value = { 
            @ApiResponse(responseCode = "201", description = "Hero created successfully"),
            @ApiResponse(responseCode = "422", description = "Invalid hero data provided")
    })
    public ResponseEntity<Hero> create(@RequestBody Hero hero) {
        // TODO: Create a DTO to avoid expose unnecessary Hero model attributes.
        Hero createdHero = heroService.create(hero);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(createdHero.getId())
                .toUri();
        return ResponseEntity.created(location).body(createdHero);
    }

    
}
